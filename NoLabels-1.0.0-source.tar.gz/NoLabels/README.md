# NoLabels 1.0.0

A small, always-on SpringBoard tweak that hides captions beneath Home Screen
apps and widgets. It has no Settings pane, preferences files, switches, or
PreferenceLoader dependency. Uninstall and respring to restore captions.

## Compatibility

Intended for iOS 18.x and iOS 26.0–26.0.1. These are target versions, not a
device-tested compatibility claim. Private SpringBoard APIs can vary between
builds. The source checks for the relevant methods before hooking them and
declines to activate outside the target versions.

Requires a jailbreak/bootstrap with working SpringBoard tweak injection and a
Substrate-compatible hook implementation. This is a conventional Theos tweak,
not an IPA, TrollStore app, or a standalone exploit/remote tweak runner payload.
OS version alone does not provide tweak injection.

Only icon captions are targeted. Text inside widgets, icon sizes, badges,
folder headers, and app names in Settings/search are not modified. Folder-icon
captions may also disappear because SpringBoard shares its icon label path.
Names and accessibility labels are not overwritten.

## Build

Use Theos with an iOS SDK supporting an 18.0 deployment target. For arm64e
SpringBoard builds use a current macOS/Xcode toolchain (see Theos documentation).

```sh
cd NoLabels
make clean package FINALPACKAGE=1
```

The default build is rootless, with arm64 and arm64e slices. The resulting
`.deb` is in `packages/`. Install using your package manager and respring.
For a rootful environment, build with:

```sh
make clean package FINALPACKAGE=1 THEOS_PACKAGE_SCHEME= THEOS_PACKAGE_ARCH=iphoneos-arm
```

## Validation status

Source/package structure and the injection filter were checked on Windows.
No iOS compilation or device testing was performed. This archive contains
source, not a precompiled/installable `.deb`.

Before release, build and test on each intended OS: app and widget captions
should stay hidden after respring, adding widgets, changing icon appearance,
opening folders, and entering/exiting edit mode. Verify widget content and
VoiceOver names remain usable; uninstall and verify captions return.

## References

- SBIconView label API reference:
  https://github.com/xybp888/iOS-Header/blob/master/13.0/PrivateFrameworks/SpringBoardHome.framework/SBIconView.h
- Theos rootless packaging and arm64e toolchain notes:
  https://theos.dev/docs/rootless
