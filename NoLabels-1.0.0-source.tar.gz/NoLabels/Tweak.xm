#import <UIKit/UIKit.h>
#import <objc/runtime.h>

@interface SBIconView : UIView
- (void)setLabelHidden:(BOOL)hidden;
- (UIView *)labelView;
@end

// App icons and Home Screen widget icons use the SBIconView label path.
// Keep the actual name intact for accessibility and other system consumers.
static void NLHideCaption(SBIconView *iconView) {
    if ([iconView respondsToSelector:@selector(setLabelHidden:)]) {
        [iconView setLabelHidden:YES];
    }
    if ([iconView respondsToSelector:@selector(labelView)]) {
        UIView *caption = [iconView labelView];
        if ([caption isKindOfClass:[UIView class]]) {
            caption.hidden = YES;
            caption.alpha = 0.0;
        }
    }
}

%group IconLayout
%hook SBIconView
- (void)layoutSubviews {
    %orig;
    NLHideCaption(self);
}
%end
%end

%group LabelVisibility
%hook SBIconView
- (void)setLabelHidden:(BOOL)hidden {
    %orig(YES);
}
%end
%end

%ctor {
    @autoreleasepool {
        NSOperatingSystemVersion version = NSProcessInfo.processInfo.operatingSystemVersion;
        BOOL supported = version.majorVersion == 18 ||
            (version.majorVersion == 26 && version.minorVersion == 0 &&
             version.patchVersion <= 1);
        if (!supported) return;

        Class iconClass = objc_getClass("SBIconView");
        // Do not add guessed private methods when an OS build lacks them.
        if (iconClass && class_getInstanceMethod(iconClass, @selector(layoutSubviews))) {
            %init(IconLayout);
        }
        if (iconClass && class_getInstanceMethod(iconClass, @selector(setLabelHidden:))) {
            %init(LabelVisibility);
        }
    }
}
